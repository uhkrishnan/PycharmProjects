'''
#tuples
Cities = ('Austin', 'Portland', 'Dallas')
print (Cities[0])

print (Cities)

citi_info = {'Austin': 81111,'Dallas': 91345}
print (citi_info['Dallas'])
print (citi_info)
'''

#sets
city_names_set = {'Austin', 'Portland', 'Dallas','Austin'}
print (city_names_set)
for set_value in city_names_set:
	print (set_value)
